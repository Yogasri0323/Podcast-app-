package de.danoeh.antennapod.ui.screen.subscriptions;

import de.danoeh.antennapod.R;

public enum SubscriptionsFilterGroup {
    COUNTER_GREATER_ZERO(new ItemProperties(R.string.subscriptions_counter_greater_zero, "counter_greater_zero")),
    AUTO_DOWNLOAD(new ItemProperties(R.string.auto_downloaded, "enabled_auto_download"),
            new ItemProperties(R.string.not_auto_downloaded, "disabled_auto_download")),
    UPDATED(new ItemProperties(R.string.kept_updated, "enabled_updates"),
            new ItemProperties(R.string.not_kept_updated, "disabled_updates")),
    NEW_EPISODE_NOTIFICATION(new ItemProperties(R.string.new_episode_notification_enabled,
                                                           "episode_notification_enabled"),
            new ItemProperties(R.string.new_episode_notification_disabled, "episode_notification_disabled"));


    public final ItemProperties[] values;

    SubscriptionsFilterGroup(ItemProperties... values) {
        this.values = values;
    }

    public static class ItemProperties {

        public final int displayName;
        public final String filterId;

        public ItemProperties(int displayName, String filterId) {
            this.displayName = displayName;
            this.filterId = filterId;
        }

    }
}

package de.danoeh.antennapod.ui;

public enum TransitionEffect {
    NONE, FADE, SLIDE
}

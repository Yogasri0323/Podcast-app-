# :model

This module provides basic model classes like `Feed` and `Chapter`.

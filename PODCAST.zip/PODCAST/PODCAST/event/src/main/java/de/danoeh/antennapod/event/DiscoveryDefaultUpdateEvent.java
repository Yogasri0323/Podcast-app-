package de.danoeh.antennapod.event;

public class DiscoveryDefaultUpdateEvent {
    public DiscoveryDefaultUpdateEvent() {
    }
}

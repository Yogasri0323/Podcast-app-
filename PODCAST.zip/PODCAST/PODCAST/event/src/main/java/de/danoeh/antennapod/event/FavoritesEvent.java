package de.danoeh.antennapod.event;

public class FavoritesEvent {

    public FavoritesEvent() {
    }
}

package de.danoeh.antennapod.event;

public class PlayerStatusEvent {
    public PlayerStatusEvent() {
    }
}

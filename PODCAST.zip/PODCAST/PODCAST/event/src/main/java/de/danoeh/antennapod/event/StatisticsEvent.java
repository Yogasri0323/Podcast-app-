package de.danoeh.antennapod.event;

public class StatisticsEvent {

    public StatisticsEvent() {
    }
}

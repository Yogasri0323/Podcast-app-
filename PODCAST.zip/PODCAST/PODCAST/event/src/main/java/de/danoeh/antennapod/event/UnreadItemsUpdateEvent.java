package de.danoeh.antennapod.event;

public class UnreadItemsUpdateEvent {
    public UnreadItemsUpdateEvent() {
    }
}

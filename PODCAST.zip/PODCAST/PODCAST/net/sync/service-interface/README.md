# :net:sync:service-interface

This module contains the interface for starting the sync service.

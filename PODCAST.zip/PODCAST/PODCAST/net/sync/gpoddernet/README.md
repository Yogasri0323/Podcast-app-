# :net:sync:gpoddernet

This module contains the sync backend for the open-source podcast synchronization service "Gpodder.net".

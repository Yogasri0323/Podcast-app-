package de.danoeh.antennapod.net.sync.gpoddernet;

public class GpodnetServiceAuthenticationException extends GpodnetServiceException {
    private static final long serialVersionUID = 1L;

    public GpodnetServiceAuthenticationException(String message) {
        super(message);
    }
}

# :net:discovery

This module contains the podcast search/discovery APIs.

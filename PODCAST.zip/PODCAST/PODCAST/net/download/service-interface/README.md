# :net:download:service-interface

Interface of the download service. Enables other modules to call the download service without actually depending on the implementation.
